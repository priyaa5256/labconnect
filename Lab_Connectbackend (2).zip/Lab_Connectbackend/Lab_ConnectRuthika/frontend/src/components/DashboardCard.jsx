import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const DashboardCard = ({ title, description, icon, path }) => {
  const navigate = useNavigate();

  return (
    <div className="card" onClick={() => navigate(path)}>
      <div className="card-icon">
        {icon}
      </div>
      <h3 className="card-title">{title}</h3>
      <p className="card-desc">{description}</p>
      <div className="card-action">
        Open Module <ArrowRight size={16} />
      </div>
    </div>
  );
};

export default DashboardCard;
