import React, { useState } from 'react';
import { Stethoscope, Clipboard } from 'lucide-react';

const Interpretation = () => {
  const [notes, setNotes] = useState('');

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Interpretation</h1>
        <p className="page-subtitle">Add clinical interpretations for complex findings.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem', gap: '0.75rem' }}>
          <Stethoscope size={24} color="#8b5cf6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Clinical Notes</h2>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '800px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Select Report to Interpret</label>
            <select 
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1', marginBottom: '1rem' }}
            >
              <option value="">Select Report...</option>
              <option value="RPT-109">RPT-109: Patient Jane Doe - Histopathology</option>
              <option value="RPT-110">RPT-110: Patient John Smith - Peripheral Smear</option>
            </select>
          </div>

          <div>
             <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Microscopic Description & Interpretation</label>
             <textarea 
               rows={8}
               value={notes}
               onChange={(e) => setNotes(e.target.value)}
               placeholder="Enter detailed clinical findings here..."
               style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1', resize: 'vertical' }}
             />
          </div>

          <button 
            style={{ 
              backgroundColor: '#8b5cf6', color: 'white', padding: '0.75rem 1.5rem', 
              borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              width: 'fit-content'
            }}
          >
            <Clipboard size={20} /> Append Note
          </button>
        </div>
      </div>
    </div>
  );
};

export default Interpretation;
