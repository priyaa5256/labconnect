package com.labconnect.repository.qualityControl;

import com.labconnect.models.qualityControl.ComplianceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord, Long> {
    List<ComplianceRecord> findByTestId(Long testId);
    List<ComplianceRecord> findByAuditType(String auditType);
}
