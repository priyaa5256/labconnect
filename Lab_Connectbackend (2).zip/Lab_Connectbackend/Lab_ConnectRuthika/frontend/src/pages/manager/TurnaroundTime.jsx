import React from 'react';
import { PieChart, Clock } from 'lucide-react';

const TurnaroundTime = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Turnaround Time (TAT) Analytics</h1>
        <p className="page-subtitle">Analyze performance bottlenecks and processing delays.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Clock size={24} color="#f59e0b" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Average TAT by Department</h2>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '600px' }}>
          
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ fontWeight: 500 }}>Hematology</span>
              <span style={{ color: '#64748b' }}>45 mins / Target: 60 mins</span>
            </div>
            <div style={{ width: '100%', height: '8px', backgroundColor: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ width: '75%', height: '100%', backgroundColor: '#10b981' }}></div>
            </div>
          </div>

          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ fontWeight: 500 }}>Biochemistry</span>
              <span style={{ color: '#64748b' }}>90 mins / Target: 120 mins</span>
            </div>
            <div style={{ width: '100%', height: '8px', backgroundColor: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ width: '65%', height: '100%', backgroundColor: '#3b82f6' }}></div>
            </div>
          </div>

          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ fontWeight: 500 }}>Microbiology</span>
              <span style={{ color: '#ef4444' }}>48 hours / Target: 36 hours (Delayed)</span>
            </div>
            <div style={{ width: '100%', height: '8px', backgroundColor: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ width: '100%', height: '100%', backgroundColor: '#ef4444' }}></div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default TurnaroundTime;
