import React from 'react';
import { ShieldAlert, AlertTriangle } from 'lucide-react';

const CriticalAlerts = () => {
  const alerts = [
    { id: 'ALT-101', patient: 'P-3029', test: 'Potassium Level', value: '6.5 mEq/L', time: '10 mins ago' },
    { id: 'ALT-102', patient: 'P-1192', test: 'Troponin-I', value: '1.2 ng/mL', time: '1 hour ago' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Critical Alerts</h1>
        <p className="page-subtitle">Immediate attention required for abnormal test values.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <ShieldAlert size={24} color="#ef4444" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Active Critical Flags</h2>
        </div>

        <div style={{ display: 'grid', gap: '1rem' }}>
          {alerts.map((alert, i) => (
            <div key={i} style={{ 
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '1.5rem', borderLeft: '4px solid #ef4444', backgroundColor: '#fef2f2',
              borderRadius: '0.5rem', border: '1px solid #fecaca'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <AlertTriangle size={24} color="#ef4444" />
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: 600, color: '#991b1b', marginBottom: '0.25rem' }}>
                    Critical Value: {alert.value}
                  </h3>
                  <p style={{ color: '#7f1d1d', fontSize: '0.875rem' }}>
                    Patient: <strong>{alert.patient}</strong> | Test: <strong>{alert.test}</strong>
                  </p>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <span style={{ display: 'block', fontSize: '0.875rem', color: '#991b1b', marginBottom: '0.5rem' }}>
                  {alert.time}
                </span>
                <button style={{ backgroundColor: '#dc2626', color: 'white', padding: '0.5rem 1rem', borderRadius: '0.375rem', border: 'none', fontWeight: 600, cursor: 'pointer' }}>
                  Acknowledge
                </button>
              </div>
            </div>
          ))}

          {alerts.length === 0 && (
            <div style={{ padding: '3rem', textAlign: 'center', color: '#64748b' }}>
              <ShieldAlert size={48} style={{ opacity: 0.2, margin: '0 auto 1rem auto' }} />
              <p>No critical alerts at this time.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CriticalAlerts;
