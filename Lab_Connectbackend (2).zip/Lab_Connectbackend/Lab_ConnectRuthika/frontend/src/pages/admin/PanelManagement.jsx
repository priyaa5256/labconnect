import React from 'react';
import { Database, FolderPlus } from 'lucide-react';

const PanelManagement = () => {
  const panels = [
    { id: 'PNL-01', name: 'Comprehensive Metabolic Panel (CMP)', tests: 14 },
    { id: 'PNL-02', name: 'Basic Metabolic Panel (BMP)', tests: 8 },
  ];

  return (
    <div>
      <div className="page-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 className="page-title">Panel Management</h1>
            <p className="page-subtitle">Group tests into orderable panels and profiles.</p>
          </div>
          <button style={{ 
            backgroundColor: '#8b5cf6', color: 'white', padding: '0.75rem 1.5rem', 
            borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.5rem'
          }}>
            <FolderPlus size={20} /> Create Panel
          </button>
        </div>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Database size={24} color="#8b5cf6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Configured Panels</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Panel ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Panel Name</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Tests Included</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {panels.map((p, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{p.id}</td>
                <td style={{ padding: '1rem' }}>{p.name}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{p.tests} Tests</td>
                <td style={{ padding: '1rem' }}>
                  <button style={{ color: '#3b82f6', background: 'none', border: 'none', fontWeight: 600, cursor: 'pointer' }}>Manage Tests</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PanelManagement;
