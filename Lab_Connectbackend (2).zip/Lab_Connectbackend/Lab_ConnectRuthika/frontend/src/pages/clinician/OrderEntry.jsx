import React, { useState } from 'react';
import { FileText, Plus } from 'lucide-react';

const OrderEntry = () => {
  const [formData, setFormData] = useState({
    patientId: '', clinicianId: '', priority: 'Routine'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Order created successfully!');
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Order Entry</h1>
        <p className="page-subtitle">Create new test orders for patients.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem', gap: '0.75rem' }}>
          <FileText size={24} color="#3b82f6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>New Order Form</h2>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '600px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Patient ID</label>
            <input 
              type="text" 
              required
              className="form-input"
              value={formData.patientId}
              onChange={(e) => setFormData({...formData, patientId: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
              placeholder="Enter Patient ID"
            />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Clinician ID</label>
            <input 
              type="text" 
              required
              className="form-input"
              value={formData.clinicianId}
              onChange={(e) => setFormData({...formData, clinicianId: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
              placeholder="Enter Clinician ID"
            />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Priority</label>
            <select 
              value={formData.priority}
              onChange={(e) => setFormData({...formData, priority: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
            >
              <option value="Routine">Routine</option>
              <option value="Urgent">Urgent</option>
              <option value="Stat">Stat (Emergency)</option>
            </select>
          </div>
          <button 
            type="submit" 
            style={{ 
              backgroundColor: '#3b82f6', color: 'white', padding: '0.75rem 1.5rem', 
              borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              width: 'fit-content'
            }}
          >
            <Plus size={20} /> Place Order
          </button>
        </form>
      </div>
    </div>
  );
};

export default OrderEntry;
