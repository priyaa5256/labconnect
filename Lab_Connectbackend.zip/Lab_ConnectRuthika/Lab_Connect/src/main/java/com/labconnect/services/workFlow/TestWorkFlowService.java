package com.labconnect.services.workFlow;


import com.labconnect.Exception.workFlow.ResourceNotFoundException;
import com.labconnect.models.workFlow.TestWorkFlow;
import com.labconnect.repository.workFlow.TestWorkFlowRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestWorkFlowService {
    private final TestWorkFlowRepository repository;

    public TestWorkFlowService(TestWorkFlowRepository repository) {
        this.repository = repository;
    }

    public List<TestWorkFlow> getAllWorkflows() {
        return repository.findAll();
    }

    public TestWorkFlow createWorkflow(TestWorkFlow workflow) {
        return repository.save(workflow);
    }

    public TestWorkFlow updateWorkflowStatus(Long id, String status) {
        TestWorkFlow workflow = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Workflow not found with id: " + id));
        workflow.setStatus(Enum.valueOf(com.labconnect.Enum.WorkflowStatus.class, status));
        return repository.save(workflow);
    }

}
