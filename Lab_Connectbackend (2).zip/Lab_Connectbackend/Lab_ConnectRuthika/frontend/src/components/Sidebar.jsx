import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { 
  Activity, Database, Stethoscope, Users, Settings, 
  ChevronDown, ChevronRight 
} from 'lucide-react';

const menuData = [
  { 
    name: 'Clinician Portal', 
    baseUrl: '/clinician', 
    icon: <Activity size={20} />,
    submenus: [
      { name: 'Dashboard Home', path: '/clinician' },
      { name: 'Order Entry', path: '/clinician/order-entry' },
      { name: 'Results View', path: '/clinician/results' },
      { name: 'Critical Alerts', path: '/clinician/alerts' },
    ]
  },
  { 
    name: 'Technician Portal', 
    baseUrl: '/technician', 
    icon: <Database size={20} />,
    submenus: [
      { name: 'Dashboard Home', path: '/technician' },
      { name: 'Specimen Collection', path: '/technician/specimen' },
      { name: 'Workflow Queue', path: '/technician/workflow' },
      { name: 'Instrument Run', path: '/technician/instrument' },
    ]
  },
  { 
    name: 'Pathologist Portal', 
    baseUrl: '/pathologist', 
    icon: <Stethoscope size={20} />,
    submenus: [
      { name: 'Dashboard Home', path: '/pathologist' },
      { name: 'Result Entry', path: '/pathologist/result-entry' },
      { name: 'Interpretation', path: '/pathologist/interpretation' },
      { name: 'Authorization', path: '/pathologist/authorization' },
    ]
  },
  { 
    name: 'Manager Portal', 
    baseUrl: '/manager', 
    icon: <Users size={20} />,
    submenus: [
      { name: 'Dashboard Home', path: '/manager' },
      { name: 'Workload Dashboard', path: '/manager/workload' },
      { name: 'Quality Dashboard', path: '/manager/quality' },
      { name: 'Turnaround Time', path: '/manager/tat' },
    ]
  },
  { 
    name: 'Admin Portal', 
    baseUrl: '/admin', 
    icon: <Settings size={20} />,
    submenus: [
      { name: 'Dashboard Home', path: '/admin' },
      { name: 'Test Catalog', path: '/admin/test-catalog' },
      { name: 'User Management', path: '/admin/users' },
      { name: 'Panel Management', path: '/admin/panels' },
      { name: 'Compliance Logs', path: '/admin/logs' },
    ]
  }
];

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  // Keep track of which accordion is open
  const [openSection, setOpenSection] = useState(
    menuData.find(m => location.pathname.startsWith(m.baseUrl))?.baseUrl || '/clinician'
  );

  const toggleSection = (baseUrl) => {
    setOpenSection(openSection === baseUrl ? null : baseUrl);
  };

  return (
    <div className="sidebar" style={{ overflowY: 'auto' }}>
      <div className="sidebar-header" onClick={() => navigate(`/`)} style={{ cursor: 'pointer' }}>
        <Activity size={24} color="#3b82f6" />
        LabConnect
      </div>
      
      <nav className="sidebar-nav" style={{ padding: '0.5rem 0' }}>
        {menuData.map((section, index) => {
          const isOpen = openSection === section.baseUrl;
          
          return (
            <div key={index} style={{ marginBottom: '0.25rem' }}>
              {/* Accordion Header */}
              <div 
                onClick={() => toggleSection(section.baseUrl)}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '0.75rem 1.5rem', cursor: 'pointer',
                  color: isOpen ? 'white' : 'var(--sidebar-text)',
                  backgroundColor: isOpen ? 'var(--sidebar-hover)' : 'transparent',
                  fontWeight: 600
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  {section.icon}
                  <span>{section.name}</span>
                </div>
                {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </div>

              {/* Submenus */}
              {isOpen && (
                <div style={{ backgroundColor: '#0b1120', padding: '0.5rem 0' }}>
                  {section.submenus.map((sub, i) => {
                    const isExactMatch = location.pathname === sub.path;
                    return (
                      <NavLink
                        key={i}
                        to={sub.path}
                        end={sub.path === section.baseUrl}
                        style={{
                          display: 'block', padding: '0.5rem 1.5rem 0.5rem 3.5rem',
                          color: isExactMatch ? 'white' : '#94a3b8',
                          textDecoration: 'none', fontSize: '0.875rem',
                          borderLeft: isExactMatch ? '3px solid #3b82f6' : '3px solid transparent',
                          backgroundColor: isExactMatch ? '#1e293b' : 'transparent'
                        }}
                      >
                        {sub.name}
                      </NavLink>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>
    </div>
  );
};

export default Sidebar;
