import React from 'react';
import DashboardCard from '../../components/DashboardCard';
import { Users, FileCheck, PieChart } from 'lucide-react';

const ManagerDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Operations Manager Portal</h1>
        <p className="page-subtitle">Oversee laboratory workload, quality control, and turnaround times.</p>
      </div>

      <div className="dashboard-grid">
        <DashboardCard 
          title="Workload Dashboard" 
          description="View active test volumes, staff assignments, and capacity." 
          icon={<Users size={24} />} 
          path="/manager/workload" 
        />
        <DashboardCard 
          title="Quality Dashboard" 
          description="Monitor QC samples, calibration logs, and compliance." 
          icon={<FileCheck size={24} />} 
          path="/manager/quality" 
        />
        <DashboardCard 
          title="Turnaround Time" 
          description="Analyze end-to-end processing times and bottleneck metrics." 
          icon={<PieChart size={24} />} 
          path="/manager/tat" 
        />
      </div>
    </div>
  );
};

export default ManagerDashboard;
