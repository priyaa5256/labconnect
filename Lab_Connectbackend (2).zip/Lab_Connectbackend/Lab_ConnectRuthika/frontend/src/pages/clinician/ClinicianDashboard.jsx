import React from 'react';
import DashboardCard from '../../components/DashboardCard';
import { FileText, FileCheck, ShieldAlert } from 'lucide-react';

const ClinicianDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Clinician Portal</h1>
        <p className="page-subtitle">Welcome back! Manage your patient orders and track results here.</p>
      </div>

      <div className="dashboard-grid">
        <DashboardCard 
          title="Order Entry" 
          description="Place new laboratory test orders for your patients." 
          icon={<FileText size={24} />} 
          path="/clinician/order-entry" 
        />
        <DashboardCard 
          title="Results View" 
          description="Review completed test results and reports." 
          icon={<FileCheck size={24} />} 
          path="/clinician/results" 
        />
        <DashboardCard 
          title="Critical Alerts" 
          description="Track critical or abnormal patient results requiring immediate attention." 
          icon={<ShieldAlert size={24} />} 
          path="/clinician/alerts" 
        />
      </div>
    </div>
  );
};

export default ClinicianDashboard;
