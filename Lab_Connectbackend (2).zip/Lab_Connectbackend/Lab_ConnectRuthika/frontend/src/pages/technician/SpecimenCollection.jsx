import React from 'react';
import { Droplet, Check, X } from 'lucide-react';

const SpecimenCollection = () => {
  const specimens = [
    { id: 'SPM-9921', orderId: 'ORD-011', type: 'Blood', status: 'Pending Collection', date: '2023-11-21' },
    { id: 'SPM-9922', orderId: 'ORD-012', type: 'Urine', status: 'Pending Collection', date: '2023-11-21' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Specimen Collection</h1>
        <p className="page-subtitle">Track and record sample collection details.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Droplet size={24} color="#3b82f6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Collection Queue</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Specimen ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Order ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Type</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Date</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Status</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {specimens.map((spm, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{spm.id}</td>
                <td style={{ padding: '1rem' }}>{spm.orderId}</td>
                <td style={{ padding: '1rem' }}>{spm.type}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{spm.date}</td>
                <td style={{ padding: '1rem' }}>
                  <span style={{ backgroundColor: '#fef3c7', color: '#b45309', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600 }}>
                    {spm.status}
                  </span>
                </td>
                <td style={{ padding: '1rem', display: 'flex', gap: '0.5rem' }}>
                  <button title="Collect" style={{ padding: '0.5rem', backgroundColor: '#ecfdf5', color: '#10b981', border: '1px solid #a7f3d0', borderRadius: '0.375rem', cursor: 'pointer' }}>
                    <Check size={16} />
                  </button>
                  <button title="Reject" style={{ padding: '0.5rem', backgroundColor: '#fef2f2', color: '#ef4444', border: '1px solid #fecaca', borderRadius: '0.375rem', cursor: 'pointer' }}>
                    <X size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SpecimenCollection;
