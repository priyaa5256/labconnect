import React, { useState } from 'react';
import { Box, Plus } from 'lucide-react';

const TestCatalog = () => {
  const tests = [
    { id: 'TST-HEM-01', name: 'Complete Blood Count', dept: 'Hematology', method: 'Automated' },
    { id: 'TST-BIO-04', name: 'Lipid Profile', dept: 'Biochemistry', method: 'Automated' },
  ];

  return (
    <div>
      <div className="page-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 className="page-title">Test Catalog</h1>
            <p className="page-subtitle">Manage master list of all available laboratory tests.</p>
          </div>
          <button style={{ 
            backgroundColor: '#3b82f6', color: 'white', padding: '0.75rem 1.5rem', 
            borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.5rem'
          }}>
            <Plus size={20} /> Add New Test
          </button>
        </div>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Box size={24} color="#3b82f6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Active Tests</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Test ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Name</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Department</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Method</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tests.map((t, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{t.id}</td>
                <td style={{ padding: '1rem' }}>{t.name}</td>
                <td style={{ padding: '1rem' }}>{t.dept}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{t.method}</td>
                <td style={{ padding: '1rem' }}>
                  <button style={{ color: '#3b82f6', background: 'none', border: 'none', fontWeight: 600, cursor: 'pointer', marginRight: '1rem' }}>Edit</button>
                  <button style={{ color: '#ef4444', background: 'none', border: 'none', fontWeight: 600, cursor: 'pointer' }}>Disable</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TestCatalog;
