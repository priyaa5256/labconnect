import React from 'react';
import { User, Bell, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const displayName = user ? user.username : 'Guest';
  const roleName = user ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'Portal';

  return (
    <header className="navbar">
      <div className="navbar-brand">
        {roleName} Portal
      </div>
      <div className="navbar-user">
        
        <span style={{ 
          backgroundColor: '#eff6ff', color: '#1d4ed8', padding: '0.25rem 0.75rem', 
          borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600, border: '1px solid #bfdbfe'
        }}>
          Role: {roleName}
        </span>
        
        <Bell size={20} style={{ cursor: 'pointer', color: '#64748b', marginLeft: '1rem' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', marginLeft: '1rem' }}>
          <div style={{
            width: '32px', height: '32px', borderRadius: '50%', backgroundColor: '#e2e8f0',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <User size={16} />
          </div>
          <span>{displayName}</span>
        </div>
        <button 
          onClick={handleLogout} 
          style={{ background: 'none', border: 'none', display: 'flex', alignItems: 'center', marginTop: '2px' }}
          title="Logout"
        >
          <LogOut size={20} style={{ cursor: 'pointer', color: '#ef4444', marginLeft: '1rem' }} />
        </button>
      </div>
    </header>
  );
};

export default Navbar;
