import React from 'react';
import { Users, BarChart2 } from 'lucide-react';

const WorkloadDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Workload Dashboard</h1>
        <p className="page-subtitle">Live tracking of laboratory testing volume and staff assignments.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '2rem' }}>
        <div className="content-panel" style={{ minHeight: 'auto' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <BarChart2 size={20} color="#3b82f6" /> Daily Volume
          </h3>
          <div style={{ display: 'flex', justifyContent: 'space-around', textAlign: 'center' }}>
            <div>
              <p style={{ fontSize: '2rem', fontWeight: 700, color: '#1e293b' }}>1,245</p>
              <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Tests Ordered</p>
            </div>
            <div>
              <p style={{ fontSize: '2rem', fontWeight: 700, color: '#10b981' }}>892</p>
              <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Tests Completed</p>
            </div>
            <div>
              <p style={{ fontSize: '2rem', fontWeight: 700, color: '#f59e0b' }}>353</p>
              <p style={{ color: '#64748b', fontSize: '0.875rem' }}>In Progress</p>
            </div>
          </div>
        </div>

        <div className="content-panel" style={{ minHeight: 'auto' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Users size={20} color="#8b5cf6" /> Staff Allocation
          </h3>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <li style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span>Hematology</span>
              <span style={{ fontWeight: 600 }}>4 Techs (Busy)</span>
            </li>
            <li style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span>Biochemistry</span>
              <span style={{ fontWeight: 600 }}>6 Techs (Optimal)</span>
            </li>
            <li style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span>Microbiology</span>
              <span style={{ fontWeight: 600 }}>3 Techs (Idle)</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default WorkloadDashboard;
