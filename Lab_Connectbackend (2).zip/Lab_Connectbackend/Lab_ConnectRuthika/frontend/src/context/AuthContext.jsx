import React, { createContext, useState, useContext } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  // In production, this would initialize from localStorage/sessionStorage
  const [user, setUser] = useState(null);

  const login = async (username, password) => {
    // This is where you call your Spring Boot Backend:
    // const response = await api.post('/auth/login', { username, password })
    // setUser({ token: response.data.token, role: response.data.role, ... })
    
    // For demonstration, simulating a backend login resolving roles:
    let role = 'clinician';
    if (username.includes('admin')) role = 'admin';
    if (username.includes('path')) role = 'pathologist';
    if (username.includes('tech')) role = 'technician';
    if (username.includes('manager')) role = 'manager';

    setUser({ username, role });
    return role;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
