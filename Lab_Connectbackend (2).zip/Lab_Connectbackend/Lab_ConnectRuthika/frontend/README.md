# LabConnect Frontend

This is the complete React frontend for the LabConnect laboratory information management system.

## Setup Instructions

Since this project was generated via React and Vite, it requires **Node.js** (v18+ recommended) and `npm` installed on your system. 

1. **Install Dependencies:**
   Navigate into the `frontend` directory and run:
   ```bash
   npm install
   ```

2. **Configure API Endpoint:**
   By default, API requests are proxied to `http://localhost:8080`. To change this, modify the target in `vite.config.js` to point to your existing Spring Boot `.NET/Java` backend URL.
   ```javascript
   proxy: {
     '/api': {
       target: 'http://localhost:8080', // Replace with backend URL
       changeOrigin: true,
     }
   }
   ```

3. **Run the Application Locally:**
   Start the development server:
   ```bash
   npm run dev
   ```
   The application will become accessible at `http://localhost:3000`.

## Architecture Overview

- `/src/components` - Shared UI logic including navigation and standard presentation widgets.
- `/src/pages` - Segmented into role-based domains (Admin, Clinician, Manager, Pathologist, Technician).
- `/src/services` - Houses the `api.js` Axios instance configured to bridge and handle requests to your backend without needing backend changes.
- `/src/App.jsx` - Main React Router file linking individual role dashboards to specific URLs.
- `/src/index.css` - Custom design system providing the rich aesthetic UI using standard CSS Variables.
