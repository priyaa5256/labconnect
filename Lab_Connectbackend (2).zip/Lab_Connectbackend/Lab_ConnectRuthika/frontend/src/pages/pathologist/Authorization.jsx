import React from 'react';
import { FileSignature, CheckCircle, XCircle } from 'lucide-react';

const Authorization = () => {
  const pendingReports = [
    { id: 'RPT-109', patient: 'P-5021', test: 'Histopathology', createdBy: 'Tech B', date: '2023-11-20' },
    { id: 'RPT-110', patient: 'P-1123', test: 'Peripheral Smear', createdBy: 'Tech A', date: '2023-11-21' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Authorization</h1>
        <p className="page-subtitle">Review and electronically sign finalized lab reports.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <FileSignature size={24} color="#f59e0b" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Pending Sign-offs</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Report ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Patient ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Test / Panel</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Prepared By</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Date</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {pendingReports.map((rpt, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{rpt.id}</td>
                <td style={{ padding: '1rem' }}>{rpt.patient}</td>
                <td style={{ padding: '1rem' }}>{rpt.test}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{rpt.createdBy}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{rpt.date}</td>
                <td style={{ padding: '1rem', display: 'flex', gap: '0.5rem' }}>
                  <button title="Authorize" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.5rem 0.75rem', backgroundColor: '#ecfdf5', color: '#10b981', border: '1px solid #a7f3d0', borderRadius: '0.375rem', cursor: 'pointer', fontWeight: 600 }}>
                    <CheckCircle size={16} /> Authorize
                  </button>
                  <button title="Reject" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.5rem 0.75rem', backgroundColor: '#fef2f2', color: '#ef4444', border: '1px solid #fecaca', borderRadius: '0.375rem', cursor: 'pointer', fontWeight: 600  }}>
                    <XCircle size={16} /> Reject
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Authorization;
