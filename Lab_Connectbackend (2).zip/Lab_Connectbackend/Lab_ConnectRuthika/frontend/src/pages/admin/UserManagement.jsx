import React from 'react';
import { Users, UserPlus } from 'lucide-react';

const UserManagement = () => {
  const users = [
    { id: 'USR-101', name: 'Dr. Sarah Connor', role: 'Clinician', email: 'sconnor@hospital.com', status: 'Active' },
    { id: 'USR-204', name: 'John Doe', role: 'Technician', email: 'jdoe@lab.com', status: 'Active' },
  ];

  return (
    <div>
      <div className="page-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 className="page-title">User Management</h1>
            <p className="page-subtitle">Manage system access, roles, and accounts.</p>
          </div>
          <button style={{ 
            backgroundColor: '#10b981', color: 'white', padding: '0.75rem 1.5rem', 
            borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.5rem'
          }}>
            <UserPlus size={20} /> Add User
          </button>
        </div>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Users size={24} color="#10b981" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Staff Directory</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>User ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Name</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Role</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Email</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{u.id}</td>
                <td style={{ padding: '1rem' }}>{u.name}</td>
                <td style={{ padding: '1rem' }}>{u.role}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{u.email}</td>
                <td style={{ padding: '1rem' }}>
                  <span style={{ backgroundColor: '#d1fae5', color: '#065f46', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600 }}>
                    {u.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserManagement;
