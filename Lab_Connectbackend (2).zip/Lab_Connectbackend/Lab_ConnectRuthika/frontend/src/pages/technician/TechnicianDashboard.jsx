import React from 'react';
import DashboardCard from '../../components/DashboardCard';
import { Droplet, Database, Settings } from 'lucide-react';

const TechnicianDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Technician Portal</h1>
        <p className="page-subtitle">Manage specimen collection, queues, and instrument runs.</p>
      </div>

      <div className="dashboard-grid">
        <DashboardCard 
          title="Specimen Collection" 
          description="Acknowledge, collect, or accept specimens." 
          icon={<Droplet size={24} />} 
          path="/technician/specimen" 
        />
        <DashboardCard 
          title="Workflow Queue" 
          description="Manage assigned tests and in-progress workflows." 
          icon={<Database size={24} />} 
          path="/technician/workflow" 
        />
        <DashboardCard 
          title="Instrument Run" 
          description="Log analyzer runs and instrument operations." 
          icon={<Settings size={24} />} 
          path="/technician/instrument" 
        />
      </div>
    </div>
  );
};

export default TechnicianDashboard;
