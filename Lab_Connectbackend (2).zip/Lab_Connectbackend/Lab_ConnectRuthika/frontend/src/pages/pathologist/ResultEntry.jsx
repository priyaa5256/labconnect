import React, { useState } from 'react';
import { FileText, Save } from 'lucide-react';

const ResultEntry = () => {
  const [formData, setFormData] = useState({
    workflowId: '', parameterId: '', value: '', flag: 'Normal'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Result saved successfully!');
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Result Entry</h1>
        <p className="page-subtitle">Record individual test parameter results.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem', gap: '0.75rem' }}>
          <FileText size={24} color="#3b82f6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Manual Entry Form</h2>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '600px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Workflow ID</label>
            <input 
              type="text" 
              required
              className="form-input"
              value={formData.workflowId}
              onChange={(e) => setFormData({...formData, workflowId: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
              placeholder="Enter Workflow ID"
            />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Parameter ID</label>
            <input 
              type="text" 
              required
              className="form-input"
              value={formData.parameterId}
              onChange={(e) => setFormData({...formData, parameterId: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
              placeholder="e.g. PARAM-HB"
            />
          </div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Result Value</label>
              <input 
                type="text" 
                required
                className="form-input"
                value={formData.value}
                onChange={(e) => setFormData({...formData, value: e.target.value})}
                style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
                placeholder="Value"
              />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Flag</label>
              <select 
                value={formData.flag}
                onChange={(e) => setFormData({...formData, flag: e.target.value})}
                style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
              >
                <option value="Normal">Normal</option>
                <option value="High">High</option>
                <option value="Low">Low</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
          </div>
          <button 
            type="submit" 
            style={{ 
              backgroundColor: '#3b82f6', color: 'white', padding: '0.75rem 1.5rem', 
              borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              width: 'fit-content'
            }}
          >
            <Save size={20} /> Save Result
          </button>
        </form>
      </div>
    </div>
  );
};

export default ResultEntry;
