import React from 'react';
import DashboardCard from '../../components/DashboardCard';
import { FileText, Stethoscope, FileSignature } from 'lucide-react';

const PathologistDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Pathologist Portal</h1>
        <p className="page-subtitle">Review, interpret, and authorize laboratory test results.</p>
      </div>

      <div className="dashboard-grid">
        <DashboardCard 
          title="Result Entry" 
          description="Enter or review raw analyzer data and manual test results." 
          icon={<FileText size={24} />} 
          path="/pathologist/result-entry" 
        />
        <DashboardCard 
          title="Interpretation" 
          description="Add clinical notes, flags, and interpret complex findings." 
          icon={<Stethoscope size={24} />} 
          path="/pathologist/interpretation" 
        />
        <DashboardCard 
          title="Authorization" 
          description="Final sign-off and authorization of patient reports." 
          icon={<FileSignature size={24} />} 
          path="/pathologist/authorization" 
        />
      </div>
    </div>
  );
};

export default PathologistDashboard;
