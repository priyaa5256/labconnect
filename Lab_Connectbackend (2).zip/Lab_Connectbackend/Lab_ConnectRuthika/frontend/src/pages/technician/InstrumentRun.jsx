import React, { useState } from 'react';
import { Settings, Save } from 'lucide-react';

const InstrumentRun = () => {
  const [formData, setFormData] = useState({
    testId: '', instrumentName: '', runDate: new Date().toISOString().split('T')[0], status: 'Passed'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Instrument run logged successfully!');
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Instrument Run</h1>
        <p className="page-subtitle">Log physical instrument outputs and sync results.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem', gap: '0.75rem' }}>
          <Settings size={24} color="#3b82f6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Log Instrument Payload</h2>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '600px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Instrument Name</label>
            <select 
              value={formData.instrumentName}
              onChange={(e) => setFormData({...formData, instrumentName: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
            >
              <option value="">Select Instrument...</option>
              <option value="Beckman Coulter DxH 900">Beckman Coulter DxH 900</option>
              <option value="Roche cobas 8000">Roche cobas 8000</option>
              <option value="Sysmex XN-2000">Sysmex XN-2000</option>
            </select>
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Test ID (Batch)</label>
            <input 
              type="text" 
              required
              className="form-input"
              value={formData.testId}
              onChange={(e) => setFormData({...formData, testId: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
              placeholder="Enter Batch or Test ID"
            />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500 }}>Run Output Status</label>
            <select 
              value={formData.status}
              onChange={(e) => setFormData({...formData, status: e.target.value})}
              style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1' }}
            >
              <option value="Passed">Passed Validation</option>
              <option value="Failed">Failed / Flagged</option>
            </select>
          </div>
          <button 
            type="submit" 
            style={{ 
              backgroundColor: '#10b981', color: 'white', padding: '0.75rem 1.5rem', 
              borderRadius: '0.375rem', border: 'none', fontWeight: 600, 
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              width: 'fit-content'
            }}
          >
            <Save size={20} /> Record Run
          </button>
        </form>
      </div>
    </div>
  );
};

export default InstrumentRun;
