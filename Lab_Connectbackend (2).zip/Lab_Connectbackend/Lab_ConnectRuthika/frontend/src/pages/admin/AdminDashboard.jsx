import React from 'react';
import DashboardCard from '../../components/DashboardCard';
import { Box, Users, Database, FileText } from 'lucide-react';

const AdminDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Administrator Portal</h1>
        <p className="page-subtitle">Configure system settings, master data, and user access.</p>
      </div>

      <div className="dashboard-grid">
        <DashboardCard 
          title="Test Catalog" 
          description="Manage individual tests, parameters, and reference ranges." 
          icon={<Box size={24} />} 
          path="/admin/test-catalog" 
        />
        <DashboardCard 
          title="User Management" 
          description="Control roles, permissions, and staff accounts." 
          icon={<Users size={24} />} 
          path="/admin/users" 
        />
        <DashboardCard 
          title="Panel Management" 
          description="Group individual tests into structured panels/profiles." 
          icon={<Database size={24} />} 
          path="/admin/panels" 
        />
        <DashboardCard 
          title="Compliance Logs" 
          description="Review system audit trails and regulatory compliance records." 
          icon={<FileText size={24} />} 
          path="/admin/logs" 
        />
      </div>
    </div>
  );
};

export default AdminDashboard;
