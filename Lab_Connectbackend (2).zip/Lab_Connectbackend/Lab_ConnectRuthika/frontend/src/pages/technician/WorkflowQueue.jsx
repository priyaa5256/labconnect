import React from 'react';
import { Database, Play, CheckCircle } from 'lucide-react';

const WorkflowQueue = () => {
  const workflows = [
    { id: 'WF-7012', test: 'Complete Blood Count', priority: 'Stat', status: 'Pending', assignedTo: 'Tech A' },
    { id: 'WF-7013', test: 'Lipid Profile', priority: 'Routine', status: 'In Progress', assignedTo: 'Self' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Workflow Queue</h1>
        <p className="page-subtitle">Manage tests assigned for analysis.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Database size={24} color="#3b82f6" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>My Tasks</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Workflow ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Test Name</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Priority</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Status</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Assigned To</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {workflows.map((wf, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{wf.id}</td>
                <td style={{ padding: '1rem' }}>{wf.test}</td>
                <td style={{ padding: '1rem' }}>
                  <span style={{ 
                    backgroundColor: wf.priority === 'Stat' ? '#fee2e2' : '#f1f5f9', 
                    color: wf.priority === 'Stat' ? '#b91c1c' : '#475569', 
                    padding: '0.25rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600 
                  }}>
                    {wf.priority}
                  </span>
                </td>
                <td style={{ padding: '1rem' }}>{wf.status}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{wf.assignedTo}</td>
                <td style={{ padding: '1rem', display: 'flex', gap: '0.5rem' }}>
                  {wf.status === 'Pending' ? (
                    <button style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.5rem 0.75rem', backgroundColor: '#eff6ff', color: '#3b82f6', border: '1px solid #bfdbfe', borderRadius: '0.375rem', cursor: 'pointer', fontWeight: 600 }}>
                      <Play size={16} /> Start
                    </button>
                  ) : (
                    <button style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.5rem 0.75rem', backgroundColor: '#ecfdf5', color: '#10b981', border: '1px solid #a7f3d0', borderRadius: '0.375rem', cursor: 'pointer', fontWeight: 600 }}>
                      <CheckCircle size={16} /> Complete
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WorkflowQueue;
