import React from 'react';
import { FileText, Shield } from 'lucide-react';

const ComplianceLogs = () => {
  const logs = [
    { id: 'LOG-8821', user: 'Dr. Smith', action: 'Authorized Result RPT-109', timestamp: '2023-11-21 14:05:22' },
    { id: 'LOG-8820', user: 'Tech A', action: 'Deleted Specimen SPM-102 (Error)', timestamp: '2023-11-21 13:45:10' },
    { id: 'LOG-8819', user: 'Admin', action: 'Modified Reference Range for TST-HEM-01', timestamp: '2023-11-21 10:00:00' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Compliance & Audit Logs</h1>
        <p className="page-subtitle">Track system modifications, access events, and regulatory trails.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Shield size={24} color="#64748b" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>System Activity Log</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Audit ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Timestamp</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>User / Actor</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Action Description</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500, color: '#64748b' }}>{log.id}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{log.timestamp}</td>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{log.user}</td>
                <td style={{ padding: '1rem' }}>{log.action}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ComplianceLogs;
