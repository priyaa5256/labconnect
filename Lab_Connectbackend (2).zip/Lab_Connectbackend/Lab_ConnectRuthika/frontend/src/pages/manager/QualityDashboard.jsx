import React from 'react';
import { FileCheck, Activity } from 'lucide-react';

const QualityDashboard = () => {
  const qcLogs = [
    { testId: 'TST-HEM-01', date: '2023-11-20', value: '1.02', target: '1.00 ± 0.05', status: 'Pass' },
    { testId: 'TST-BIO-04', date: '2023-11-20', value: '1.12', target: '1.00 ± 0.05', status: 'Fail' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Quality Control Dashboard</h1>
        <p className="page-subtitle">Monitor instrument calibrations and QC runs.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', gap: '0.75rem' }}>
          <Activity size={24} color="#10b981" />
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Recent QC Runs</h2>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Test ID</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Run Date</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>QC Value</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Target Range</th>
              <th style={{ padding: '1rem', fontWeight: 600 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {qcLogs.map((qc, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '1rem', fontWeight: 500 }}>{qc.testId}</td>
                <td style={{ padding: '1rem' }}>{qc.date}</td>
                <td style={{ padding: '1rem', fontWeight: 600 }}>{qc.value}</td>
                <td style={{ padding: '1rem', color: '#64748b' }}>{qc.target}</td>
                <td style={{ padding: '1rem' }}>
                  <span style={{ 
                    backgroundColor: qc.status === 'Pass' ? '#d1fae5' : '#fee2e2', 
                    color: qc.status === 'Pass' ? '#065f46' : '#991b1b', 
                    padding: '0.25rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600 
                  }}>
                    {qc.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default QualityDashboard;
