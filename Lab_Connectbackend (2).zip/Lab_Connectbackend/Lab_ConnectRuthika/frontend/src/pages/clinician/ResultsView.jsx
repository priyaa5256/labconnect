import React from 'react';
import { FileCheck, Search } from 'lucide-react';

const ResultsView = () => {
  const dummyResults = [
    { id: 'ORD-001', patient: 'P-1004', test: 'Complete Blood Count', status: 'Authorized', date: '2023-11-20' },
    { id: 'ORD-002', patient: 'P-9021', test: 'Lipid Panel', status: 'Authorized', date: '2023-11-19' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Results View</h1>
        <p className="page-subtitle">Access authorized lab reports and test results.</p>
      </div>

      <div className="content-panel">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <FileCheck size={24} color="#10b981" />
            <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Completed Tests</h2>
          </div>
          <div style={{ position: 'relative' }}>
            <Search size={18} style={{ position: 'absolute', left: '10px', top: '10px', color: '#64748b' }} />
            <input 
              type="text" 
              placeholder="Search patient or order ID..." 
              style={{ padding: '0.5rem 1rem 0.5rem 2.5rem', borderRadius: '0.375rem', border: '1px solid #cbd5e1', width: '250px' }}
            />
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #e2e8f0', color: '#64748b' }}>
                <th style={{ padding: '1rem', fontWeight: 600 }}>Order ID</th>
                <th style={{ padding: '1rem', fontWeight: 600 }}>Patient ID</th>
                <th style={{ padding: '1rem', fontWeight: 600 }}>Test Name</th>
                <th style={{ padding: '1rem', fontWeight: 600 }}>Date</th>
                <th style={{ padding: '1rem', fontWeight: 600 }}>Status</th>
                <th style={{ padding: '1rem', fontWeight: 600 }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {dummyResults.map((res, i) => (
                <tr key={i} style={{ borderBottom: '1px solid #e2e8f0' }}>
                  <td style={{ padding: '1rem', fontWeight: 500 }}>{res.id}</td>
                  <td style={{ padding: '1rem' }}>{res.patient}</td>
                  <td style={{ padding: '1rem' }}>{res.test}</td>
                  <td style={{ padding: '1rem', color: '#64748b' }}>{res.date}</td>
                  <td style={{ padding: '1rem' }}>
                    <span style={{ backgroundColor: '#d1fae5', color: '#065f46', padding: '0.25rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600 }}>
                      {res.status}
                    </span>
                  </td>
                  <td style={{ padding: '1rem' }}>
                    <button style={{ color: '#3b82f6', background: 'none', border: 'none', fontWeight: 600, cursor: 'pointer' }}>
                      View Report
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ResultsView;
