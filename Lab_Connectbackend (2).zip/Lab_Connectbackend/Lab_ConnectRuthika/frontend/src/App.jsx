import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';

// Clinician Pages
import ClinicianDashboard from './pages/clinician/ClinicianDashboard';
import OrderEntry from './pages/clinician/OrderEntry';
import ResultsView from './pages/clinician/ResultsView';
import CriticalAlerts from './pages/clinician/CriticalAlerts';

// Technician Pages
import TechnicianDashboard from './pages/technician/TechnicianDashboard';
import SpecimenCollection from './pages/technician/SpecimenCollection';
import WorkflowQueue from './pages/technician/WorkflowQueue';
import InstrumentRun from './pages/technician/InstrumentRun';

// Pathologist Pages
import PathologistDashboard from './pages/pathologist/PathologistDashboard';
import ResultEntry from './pages/pathologist/ResultEntry';
import Interpretation from './pages/pathologist/Interpretation';
import Authorization from './pages/pathologist/Authorization';

// Manager Pages
import ManagerDashboard from './pages/manager/ManagerDashboard';
import WorkloadDashboard from './pages/manager/WorkloadDashboard';
import QualityDashboard from './pages/manager/QualityDashboard';
import TurnaroundTime from './pages/manager/TurnaroundTime';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import TestCatalog from './pages/admin/TestCatalog';
import UserManagement from './pages/admin/UserManagement';
import PanelManagement from './pages/admin/PanelManagement';
import ComplianceLogs from './pages/admin/ComplianceLogs';

import { AuthProvider } from './context/AuthContext';
import Login from './pages/Login';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Navigate to="/login" replace />} />

        {/* Clinician Routes */}
        <Route path="/clinician" element={<Layout role="clinician" />}>
          <Route index element={<ClinicianDashboard />} />
          <Route path="order-entry" element={<OrderEntry />} />
          <Route path="results" element={<ResultsView />} />
          <Route path="alerts" element={<CriticalAlerts />} />
        </Route>

        {/* Technician Routes */}
        <Route path="/technician" element={<Layout role="technician" />}>
          <Route index element={<TechnicianDashboard />} />
          <Route path="specimen" element={<SpecimenCollection />} />
          <Route path="workflow" element={<WorkflowQueue />} />
          <Route path="instrument" element={<InstrumentRun />} />
        </Route>

        {/* Pathologist Routes */}
        <Route path="/pathologist" element={<Layout role="pathologist" />}>
          <Route index element={<PathologistDashboard />} />
          <Route path="result-entry" element={<ResultEntry />} />
          <Route path="interpretation" element={<Interpretation />} />
          <Route path="authorization" element={<Authorization />} />
        </Route>

        {/* Manager Routes */}
        <Route path="/manager" element={<Layout role="manager" />}>
          <Route index element={<ManagerDashboard />} />
          <Route path="workload" element={<WorkloadDashboard />} />
          <Route path="quality" element={<QualityDashboard />} />
          <Route path="tat" element={<TurnaroundTime />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={<Layout role="admin" />}>
          <Route index element={<AdminDashboard />} />
          <Route path="test-catalog" element={<TestCatalog />} />
          <Route path="users" element={<UserManagement />} />
          <Route path="panels" element={<PanelManagement />} />
          <Route path="logs" element={<ComplianceLogs />} />
        </Route>

        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
